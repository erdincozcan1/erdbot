/**
 * Hyperliquid takip botu — anlık komut yanıtlayıcı (Cloudflare Worker)
 *
 * Telegram'da /durum veya /rapor yazınca birkaç saniye içinde cevap verir.
 * GitHub deposundaki hl_state.json ve hl_traders.json dosyalarını okur,
 * açık sanal pozisyonları Hyperliquid'in o anki fiyatlarıyla değerler.
 * Hiç işlem açmaz; sadece okur ve mesaj gönderir.
 *
 * Gerekli değişkenler (Cloudflare → Worker → Settings → Variables and Secrets):
 *   TELEGRAM_BOT_TOKEN   Telegram bot token'ı
 *   TELEGRAM_CHAT_ID     senin chat ID'n (yalnızca bu sohbete cevap verilir)
 *   GITHUB_REPO          "kullaniciadi/depoadi"
 *   GITHUB_TOKEN         depo özel (private) ise: yalnızca o depoda "Contents: Read-only" yetkili token
 *   WEBHOOK_SECRET       kendi belirlediğin uzun rastgele bir kelime (ör. 30+ harf/rakam)
 *   GITHUB_DISPATCH      "1" ise: Cron tetikleyicisi her çalıştığında GitHub botunu başlatır
 *                        (token'ın "Actions: Read and write" yetkisi de olmalı)
 *
 * Güvenilir 5 dakikalık çalışma için: Worker → Settings → Trigger events → Cron → "her 5 dakikada bir" (ifade: yıldız-bölü-5 ve dört yıldız)
 *
 * Kurulumdan sonra bir kez tarayıcıda aç:  https://<worker-adresi>/setup?key=<WEBHOOK_SECRET>
 */

const HL_API = "https://api.hyperliquid.xyz/info";
const DISCLAIMER = "<i>Simülasyondur, yatırım tavsiyesi değildir.</i>";

export default {
  // Cron tetikleyicisi: GitHub'ın kendi zamanlayıcısı güvenilir olmadığı için botu buradan başlatır
  async scheduled(event, env, ctx) {
    env = clean(env);
    if (env.GITHUB_DISPATCH !== "1") return;
    ctx.waitUntil(dispatchWorkflow(env));
  },

  async fetch(request, env) {
    env = clean(env);
    const url = new URL(request.url);

    // Teşhis sayfası: ayarların ve Telegram bağlantısının durumunu gösterir (token'ları göstermez)
    if (request.method === "GET" && url.pathname === "/check") {
      if (!env.WEBHOOK_SECRET || url.searchParams.get("key") !== env.WEBHOOK_SECRET) {
        return new Response("Yetkisiz", { status: 403 });
      }
      const out = { ayarlar: {}, beklenen_webhook: `${url.origin}/telegram` };
      for (const k of ["TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "GITHUB_REPO", "GITHUB_TOKEN", "GITHUB_DISPATCH", "WEBHOOK_SECRET"]) {
        out.ayarlar[k] = env[k] ? "var" : "EKSİK";
      }
      out.ayarlar.TELEGRAM_CHAT_ID_degeri = env.TELEGRAM_CHAT_ID || null;
      out.ayarlar.GITHUB_REPO_degeri = env.GITHUB_REPO || null;
      try {
        const me = await tg(env, "getMe", {});
        out.telegram_token = me.ok ? `geçerli (@${me.result.username})` : `GEÇERSİZ: ${me.description}`;
        const wh = await tg(env, "getWebhookInfo", {});
        if (wh.ok) {
          const w = wh.result;
          out.webhook = {
            adres: w.url || "(ayarlanmamış — /setup sayfasını aç)",
            dogru_adres_mi: w.url === `${url.origin}/telegram`,
            bekleyen_mesaj: w.pending_update_count,
            son_hata: w.last_error_message || "yok",
            son_hata_zamani: w.last_error_date ? new Date(w.last_error_date * 1000).toISOString() : null,
          };
        }
      } catch (e) { out.telegram_token = "Telegram'a ulaşılamadı: " + String(e); }
      try {
        await loadRepo(env);
        out.github = "dosyalar okunabiliyor";
      } catch (e) { out.github = "HATA: " + String(e); }
      // Botu başlatma yetkisini dener (başarılıysa GitHub'da bir çalışma başlar)
      out.GITHUB_DISPATCH_degeri = env.GITHUB_DISPATCH || null;
      try {
        const st = await dispatchWorkflow(env);
        out.bot_baslatma = st === 204 ? "çalışıyor: GitHub'da yeni bir çalışma başlatıldı"
          : st === 403 ? "HATA 403: GITHUB_TOKEN'da 'Actions: Read and write' yetkisi yok"
          : st === 401 ? "HATA 401: GITHUB_TOKEN hatalı veya süresi dolmuş"
          : st === 404 ? "HATA 404: depo adı yanlış ya da token'a bu depo seçilmemiş"
          : st === 422 ? "HATA 422: iş akışı dosyası (hl_watch.yml) veya 'main' dalı bulunamadı"
          : "HATA " + st;
      } catch (e) { out.bot_baslatma = "HATA: " + String(e); }
      out.not = "5 dakikalık otomatik başlatma için ayrıca Settings → Trigger events bölümünde '*/5 * * * *' Cron Trigger'ı ekli olmalı ve GITHUB_DISPATCH = 1 olmalı.";
      return new Response(JSON.stringify(out, null, 2), { headers: { "content-type": "application/json; charset=utf-8" } });
    }

    // Tek seferlik kurulum: Telegram webhook'unu bu Worker'a yönlendirir
    if (request.method === "GET" && url.pathname === "/setup") {
      if (!env.WEBHOOK_SECRET || url.searchParams.get("key") !== env.WEBHOOK_SECRET) {
        return new Response("Yetkisiz", { status: 403 });
      }
      const r = await tg(env, "setWebhook", {
        url: `${url.origin}/telegram`,
        secret_token: env.WEBHOOK_SECRET,
        allowed_updates: ["message"],
        drop_pending_updates: true,
      });
      return new Response(JSON.stringify(r, null, 2), { headers: { "content-type": "application/json" } });
    }

    if (request.method === "POST" && url.pathname === "/telegram") {
      if (request.headers.get("X-Telegram-Bot-Api-Secret-Token") !== env.WEBHOOK_SECRET) {
        return new Response("Yetkisiz", { status: 403 });
      }
      let update;
      try { update = await request.json(); } catch { return new Response("ok"); }
      const msg = update.message || {};
      const chatId = String((msg.chat || {}).id || "");
      const text = String(msg.text || "").trim().split("@")[0].toLowerCase();
      if (chatId !== String(env.TELEGRAM_CHAT_ID)) {
        console.log("Başka bir sohbetten mesaj geldi, yok sayıldı. Gelen chat id:", chatId);
        return new Response("ok");
      }
      if (!text.startsWith("/")) return new Response("ok");

      try {
        if (text === "/durum" || text === "/rapor" || text === "/gozlem" || text === "/gözlem") {
          const { cfg, state } = await loadRepo(env);
          if (!state) {
            await send(env, "Henüz kayıt yok. GitHub'daki bot ilk kez çalıştıktan sonra tekrar dene.");
          } else {
            normalize(state, cfg);
            const mids = await fetchMids(cfg.dexes || [""]);
            if (text === "/durum") await send(env, summaryText(state, cfg, mids, "Anlık durum") + "\n\n" + DISCLAIMER);
            else if (text === "/rapor") await send(env, weeklyText(state, cfg, mids));
            else await send(env, benchText(state, mids));
          }
        } else {
          await send(env, "Komutlar: /durum · /rapor · /gozlem\nCevaplar birkaç saniye içinde gelir. " +
                          "Trader hareketleri GitHub botu tarafından birkaç dakikada bir işlenir.");
        }
      } catch (err) {
        await send(env, "⚠️ Veri alınamadı: " + esc(String(err).slice(0, 200)));
      }
      return new Response("ok");
    }

    return new Response("Hyperliquid takip botu çalışıyor.");
  },
};

// ------------------------------------------------------------------ yardımcılar

async function dispatchWorkflow(env) {
  const r = await fetch(`https://api.github.com/repos/${env.GITHUB_REPO}/actions/workflows/hl_watch.yml/dispatches`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${env.GITHUB_TOKEN}`,
      "Accept": "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "User-Agent": "hl-watch-worker",
    },
    body: JSON.stringify({ ref: "main" }),
  });
  if (r.status !== 204) console.log("GitHub tetikleme başarısız:", r.status, await r.text());
  return r.status;
}

// Ayarlara yanlışlıkla eklenen boşluk/satır sonlarını temizler (en sık hata sebebi)
function clean(env) {
  const out = {};
  for (const [k, v] of Object.entries(env)) out[k] = typeof v === "string" ? v.trim() : v;
  return out;
}

function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

function usd(x, sign = false) {
  const s = sign && x > 0 ? "+" : x < 0 ? "−" : "";
  const a = Math.abs(x);
  const f = (v, d) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
  if (a >= 1e6) return `${s}${f(a / 1e6, 2)}M$`;
  if (a >= 1e4) return `${s}${f(a / 1e3, 1)}K$`;
  return `${s}${f(a, 2)}$`;
}

function pct(x) { return `${x > 0 ? "+" : x < 0 ? "−" : ""}%${(Math.abs(x) * 100).toFixed(1)}`; }

function side(s) { return s > 0 ? "LONG" : "SHORT"; }

async function tg(env, method, body) {
  const r = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body),
  });
  return r.json();
}

async function send(env, text) {
  for (let i = 0; i < text.length; i += 3900) {
    await tg(env, "sendMessage", {
      chat_id: env.TELEGRAM_CHAT_ID, text: text.slice(i, i + 3900),
      parse_mode: "HTML", disable_web_page_preview: true,
    });
  }
}

async function ghFile(env, path) {
  const headers = { "Accept": "application/vnd.github.raw+json", "User-Agent": "hl-watch-worker" };
  if (env.GITHUB_TOKEN) headers["Authorization"] = `Bearer ${env.GITHUB_TOKEN}`;
  const r = await fetch(`https://api.github.com/repos/${env.GITHUB_REPO}/contents/${path}`, { headers });
  if (r.status === 404) return null;
  if (!r.ok) throw new Error(`GitHub ${path}: HTTP ${r.status}`);
  return JSON.parse(await r.text());
}

async function loadRepo(env) {
  const [cfg, state] = await Promise.all([ghFile(env, "hl_traders.json"), ghFile(env, "hl_state.json")]);
  if (!cfg) throw new Error("hl_traders.json depoda bulunamadı");
  return { cfg, state };
}

async function fetchMids(dexes) {
  const out = {};
  for (const dex of dexes) {
    const r = await fetch(HL_API, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ type: "allMids", dex }),
    });
    const j = await r.json();
    for (const [k, v] of Object.entries(j || {})) { const n = Number(v); if (isFinite(n)) out[k] = n; }
  }
  return out;
}

// --------------------------------------------- sanal portföy (hl_watcher.py ile aynı)

function subEquity(sub, mids) {
  let upnl = 0;
  for (const [c, p] of Object.entries(sub.positions || {})) upnl += p.sz * ((mids[c] ?? p.entry) - p.entry);
  return sub.capital + sub.realized - sub.fees + upnl;
}

// Eski (tek liste) ve yeni (ana kopya + gözlem) durum dosyalarını aynı biçime getirir
function normalize(state, cfg) {
  if ((state.version || 1) < 2) {
    const keep = new Set((cfg.traders || []).filter(t => t.copy !== false).map(t => t.address.toLowerCase()));
    state.subs = Object.fromEntries(Object.entries(state.subs || {}).filter(([a]) => keep.has(a)));
    state.roles = Object.fromEntries((cfg.traders || []).map(t => [t.address.toLowerCase(), { label: t.label, role: "active" }]));
    state.shadow = {};
    state.closed_pnl = 0;
    state._slots = Object.keys(state.subs).length || 1;
  } else {
    state._slots = ((cfg.rotation || {}).slots) || ((state.rotation || {}).slots) || Object.keys(state.subs || {}).length || 1;
  }
  state._per = (cfg.paper_capital_usd || 0) / state._slots;
  state._free = Math.max(0, state._slots - Object.keys(state.subs || {}).length);
}

function labelOf(state, a) { return ((state.roles || {})[a] || {}).label || a.slice(0, 8); }

function totalEquity(state, mids) {
  return Object.values(state.subs).reduce((s, sub) => s + subEquity(sub, mids), 0)
    + (state.closed_pnl || 0) + state._free * state._per;
}

function totalCapital(state) {
  return Object.values(state.subs).reduce((s, x) => s + x.capital, 0) + state._free * state._per;
}

function maxDrawdown(history, current) {
  let peak = 0, mdd = 0;
  for (const v of [...(history || []).map(h => h[1]), current]) {
    peak = Math.max(peak, v);
    if (peak > 0) mdd = Math.max(mdd, 1 - v / peak);
  }
  return mdd;
}

function daysSince(iso) { return iso ? (Date.now() - Date.parse(iso)) / 864e5 : 0; }

function summaryText(state, cfg, mids, title) {
  const subs = Object.values(state.subs);
  const cap = totalCapital(state);
  const eq = totalEquity(state, mids);
  const realized = subs.reduce((s, x) => s + x.realized, 0);
  const fees = subs.reduce((s, x) => s + x.fees, 0);
  const upnl = subs.reduce((s, x) => s + subEquity(x, mids) - x.capital - x.realized + x.fees, 0);
  const rows = Object.entries(state.subs).map(([addr, s]) => {
    const se = subEquity(s, mids);
    const poss = Object.entries(s.positions || {}).map(([c, p]) => `${c} ${side(p.sz)}`).join(", ") || "pozisyon yok";
    return [se / s.capital - 1, `• ${esc(labelOf(state, addr))}: ${usd(se)} (${pct(se / s.capital - 1)}) · ` +
                                `${s.trades} işlem, ${s.skipped} atlanan · ${esc(poss)}`];
  }).sort((a, b) => b[0] - a[0]).map(r => r[1]);
  const lines = [
    `📊 <b>${title}</b>`,
    `Başlangıç ${esc(String(state.started).slice(0, 10))} · sermaye ${usd(cap)}`,
    `<b>Sanal portföy: ${usd(eq)} (${pct(eq / cap - 1)})</b>`,
    `Gerçekleşen ${usd(realized, true)} · açık ${usd(upnl, true)} · ücret ${usd(-fees)}`,
  ];
  if (state.closed_pnl) lines.push(`Listeden çıkarılanların sonucu: ${usd(state.closed_pnl, true)}`);
  if (state._free) lines.push(`Boş yer: ${state._free} (nakit bekliyor)`);
  lines.push(`En büyük düşüş: ${pct(-maxDrawdown(state.history, eq))}`, "", `<b>Ana kopya (${subs.length})</b>`, ...rows);
  const nb = Object.keys(state.shadow || {}).length;
  if (nb) lines.push("", `Gözlemde ${nb} trader (ayrıntı: /gozlem)`);
  lines.push("", "<i>Fiyatlar anlık; son işlemler birkaç dakika gecikmeli işlenir.</i>");
  return lines.join("\n");
}

function benchText(state, mids) {
  const sh = Object.entries(state.shadow || {});
  if (!sh.length) return "👁 Gözlem listesi boş.";
  const rows = sh.map(([a, s]) => {
    const r = subEquity(s, mids) / s.capital - 1;
    const role = (state.roles || {})[a] || {};
    return [r, `• ${esc(labelOf(state, a))}: gölge ${pct(r)} · ${daysSince(role.since).toFixed(0)} gün gözlemde`];
  }).sort((a, b) => b[0] - a[0]).map(x => x[1]);
  return "👁 <b>Gözlem listesi</b> (gölge portföy: kopyalansaydı ne olurdu; ana portföye katılmaz)\n" + rows.join("\n") +
         "\n\n<i>Geri dönüş için: en az 42 gün gözlem, gölge portföy +%5 üstü, risk işareti yok. Kararı her sabah bot verir.</i>";
}

function weeklyText(state, cfg, mids) {
  const eq = totalEquity(state, mids);
  const last = (state.last_report || {}).equity || eq;
  let text = summaryText(state, cfg, mids, "Rapor");
  text = text.replace("\n", `\nBu hafta: ${pct(eq / last - 1)}\n`);
  const weekAgo = Date.now() - 7 * 864e5;
  const ch = (((state.rotation || {}).changes) || []).filter(c => Date.parse(c[0]) >= weekAgo);
  if (ch.length) {
    const kinds = { risk: "risk", perf: "performans", swap: "yer değiştirme", "swap-in": "yer değiştirme",
                    promote: "geri döndü", new: "yeni aday", manual: "elle", remove: "silindi" };
    text += "\n\n<b>Bu haftaki kadro değişiklikleri</b>\n" +
      ch.map(c => `• ${c[0].slice(5, 10)} ${esc(c[3] || labelOf(state, c[2]))}: ${kinds[c[1]] || c[1]}`).join("\n");
  }
  if (Object.keys(state.shadow || {}).length) text += "\n\n" + benchText(state, mids);
  return text + "\n\n" + DISCLAIMER;
}
